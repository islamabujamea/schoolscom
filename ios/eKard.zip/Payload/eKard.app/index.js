export const RegularFont = 'Poppins-Regular';
export const BoldFont = 'Poppins-Bold';
export const BoldItalicFont = 'Poppins-Italic';
